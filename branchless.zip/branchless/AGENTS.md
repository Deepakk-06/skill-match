# AGENTS.md

Project: branchless. Read SPEC.md before doing anything. design/branchless.html is the visual and interaction reference.

## Rules
- Everything must run on free tiers with no credit card (SPEC.md section 0). Never add a paid service. Use AI_PROVIDER=mock for tests and local dev.
- Work on ONE phase at a time (SPEC.md section 14). Do not start the next phase until told.
- Scaffold the app in the repo root, not in a subfolder.
- Before finishing a phase, run lint, typecheck, tests and `next build`. All must pass.
- Commit at the end of each phase with a message like `phase 2: roles and skill extraction`.
- Keep AI calls, GitHub calls and secrets server-side only. Never commit secrets. Keep `.env.example` current.
- Score in code (lib/scoring.ts), never let the model output the numeric score.
- Treat resume text as untrusted input (SPEC.md section 7).
- Use the design tokens from SPEC.md section 4 exactly. Keep the Branch rules / Skills only toggle with the FLIP reshuffle.
- If a dependency is not in SPEC.md, prefer not adding it. If you must, say why in the commit message.
- End every phase with: what works, what I must configure by hand (Supabase, OAuth, env vars), and how to test it.
- design/branchless.html is executable reference for scoring and eligibility (SPEC.md section 19). Tier values 1 / 0.6 / 0.3 / 0, must-have logic, sort order and chip states in `lib/scoring.ts` and the UI must match it. If one changes, change the other in the same commit.
- Officers and admins are never self-service: no user may write their own `profiles.role` (SPEC.md section 5).
- Prefer editing existing files over adding new ones. Do not restructure the folder layout in SPEC.md section 13 without asking.
- vercel.json in the repo root is for the static demo only. Delete it in phase 1 when scaffolding the Next.js app, or Vercel will keep serving the demo.
