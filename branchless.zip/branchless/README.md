# branchless

Branch-based eligibility filters out students who have the skills. branchless ranks candidates by the skills they can prove.

## Why it exists

Some students have real skills and still get blocked by an eligibility rule that only looks at their branch. Someone with robotics and OpenCV projects can be shut out of a role while a student with nothing relevant is allowed in. That is frustrating, and it is unfair to the student and to the company.

**Made by a student, for students.**

## What is in this repo

| File | What it is |
|---|---|
| `design/branchless.html` | Interactive demo. Open it in a browser. Eight role presets, eleven made-up students, five themes, the Branch rules / Skills only toggle, CSV export. |
| `SPEC.md` | The full build spec for the real app (Next.js, Supabase, Gemini free tier, GitHub proof). |
| `AGENTS.md` | Rules for the coding agent that builds it, one phase at a time. |
| `vercel.json` | Serves the demo as a static site. **Delete this file when the Next.js app is added.** |

## How tiers and scoring work

- **verified** (100%): a project uses the skill and the student's code shows it.
- **claimed** (60%): a project describes it, no code evidence yet.
- **listed only** (30%): appears only in a skills list.
- **missing** (0%).

The score is calculated in code, never by the AI. Skills-only eligibility means the score meets the role's minimum and every must-have skill is at least claimed.

## Limitations

A resume can still exaggerate. GitHub proof helps but is not perfect, and skills with no code footprint (CAD, PCB design) cannot reach verified from GitHub alone. Scores are decision support for humans, not final decisions. Nobody is auto-rejected.

## Privacy

Resumes are personal data. In the full app, resume text is sent to an AI provider for the check and shared with the placement cell only if the student applies. On the free Gemini tier, Google may use prompts to improve its products. The provider is swappable.

## Build it

Give `SPEC.md` and `AGENTS.md` to your coding agent and work through the phases in order.

## License

MIT
